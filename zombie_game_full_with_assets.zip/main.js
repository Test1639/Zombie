
const config = {
  type: Phaser.AUTO,
  width: 896,
  height: 512,
  physics: {
    default: 'arcade',
    arcade: {
      gravity: { y: 0 },
      debug: false
    }
  },
  scene: {
    preload: preload,
    create: create,
    update: update
  }
};

const game = new Phaser.Game(config);

let player, cursors, background, zombies, zombieTimer = 0;

function preload() {
  this.load.image('bg', 'assets/background.png');
  this.load.image('soldier', 'assets/soldier.png');
  this.load.image('zombie', 'assets/zombie.png');
}

function create() {
  background = this.add.tileSprite(0, 0, 896, 512, 'bg').setOrigin(0, 0);

  player = this.physics.add.sprite(100, 400, 'soldier');
  player.setScale(2);
  player.setCollideWorldBounds(true);

  zombies = this.physics.add.group();
  this.physics.add.overlap(player, zombies, gameOver, null, this);

  cursors = this.input.keyboard.createCursorKeys();
}

function update(time, delta) {
  background.tilePositionX += 2;

  if (time > zombieTimer) {
    let zombie = zombies.create(896, 400, 'zombie');
    zombie.setVelocityX(-100);
    zombie.setScale(2);
    zombieTimer = time + 1500;
  }
}

function gameOver() {
  this.scene.restart();
}
